package com.pms.ServiceImp;

import com.pms.service.PMS_Service2;

public class PMS_ServiceImpl2 implements PMS_Service2 {

}
