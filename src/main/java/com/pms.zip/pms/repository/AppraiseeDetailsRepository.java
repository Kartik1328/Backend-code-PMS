package com.pms.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.pms.Model.AppraiseeDetails;

public interface AppraiseeDetailsRepository extends JpaRepository<AppraiseeDetails,Long> {
	
	

}
