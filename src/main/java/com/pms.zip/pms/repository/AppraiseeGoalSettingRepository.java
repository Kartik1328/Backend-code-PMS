package com.pms.repository;

public interface AppraiseeGoalSettingRepository {

}
