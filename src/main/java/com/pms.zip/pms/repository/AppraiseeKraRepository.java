package com.pms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pms.Model.AppraiseeKra;

public interface AppraiseeKraRepository extends JpaRepository<AppraiseeKra,Long> {

}
