package com.pms.repository;

public interface AppraiseeDevelopmentGoalSettingDraftRepository {

}
