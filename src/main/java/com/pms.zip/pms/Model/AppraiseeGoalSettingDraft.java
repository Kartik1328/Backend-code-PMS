package com.pms.Model;

public class AppraiseeGoalSettingDraft {

}
