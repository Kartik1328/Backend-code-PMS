package com.pms.Model;

public class AppraiseeGoalSetting {

}
