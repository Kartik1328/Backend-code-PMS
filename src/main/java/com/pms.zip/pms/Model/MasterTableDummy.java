package com.pms.Model;

public class MasterTableDummy {

}
