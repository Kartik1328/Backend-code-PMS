package com.pms.service;

public interface PMS_Service2 {

}
